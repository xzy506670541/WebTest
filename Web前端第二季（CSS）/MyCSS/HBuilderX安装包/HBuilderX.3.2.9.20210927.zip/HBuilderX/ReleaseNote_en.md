# HBuilder X - Release Notes
======================================
## 3.2.9.20210927
* Added HBuilderX supports localized language pack extension [Details](https://github.com/dcloudio/hbuilderx-language-packs)
* Vue3 improvements [Details](https://hx.dcloud.net.cn/Tutorial/Language/vue-next)
* Added Configure whether you receive automatic updates.